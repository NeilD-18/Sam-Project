# space.py
import pygame, time, random
# A basic space game.
# Author: Matthew Anderson
# Version: Fall 2017


## ----------------------------------------------------------------------
##     Initialize Global Variables
## ----------------------------------------------------------------------

## Initialize the pygame submodules and set up the display window.
pygame.init()

# Global variables for the window.
WIDTH = 640
HEIGHT = 480
RADIUS = 10
MY_WIN = pygame.display.set_mode((WIDTH, HEIGHT))

# Global variables containing properties of the ship and lasers
SHIP_DY = 5
LASER_DX = 5
SCORE = 0

## ----------------------------------------------------------------------
##     Helper Functions
## ----------------------------------------------------------------------

def collide(circ1, circ2):
    '''
    circ1 and circ2 are tuples of the form ((x,y),radius)) that
    describe circles.  This function returns True if the circles
    are overlaping and False otherwise.

    This is code from Lab 4
    '''

    ((x1, y1), r1) = circ1
    ((x2, y2), r2) = circ2

    d = ((x1 - x2)**2 + (y1 - y2)**2)**0.5

    result = d <= r1 + r2

    return result  

## ----------------------------------------------------------------------
##     Ship Functions
## ----------------------------------------------------------------------

def fire_laser(lasers, ship):
    '''
    this function will fire lasers when given the inputs lasers or ship. It
    returns a laser.
    '''

    # Add a laser at the ship's location.
    lasers.append(ship)

def move_ship_up(ship):
    '''
    this function will move the ship up. It expects a number value as input
    and it will return the ships new location moving upwards. 
    '''

    (sx, sy) = ship
    sy = sy - SHIP_DY
    # Prevent the ship from going off the top of the screen.
    if sy < 0:
        sy = 0

    return (sx,sy)

def move_ship_down(ship):
    '''
    this function will move the ship down the screen. It expects a numeric value as
    an input and it will return the ships new location moving downwards.
    '''

    global HEIGHT

    (sx, sy) = ship
    # Prevent the ship from going off the bottom of the screen.
    sy = sy + SHIP_DY
    if sy > HEIGHT:
        sy = HEIGHT

    return (sx,sy)

def draw_ship(ship):
    '''
    This function will draw the blue triangular ship. it expects ship as an input and
    it will return a blue triangle on the left side of the screen. 
    '''

    global MY_WIN # Need to access the global variable for the window to draw

    # Unpack the coordinates of the ship
    (sx, sy) = ship
    # Determine the outline of the ship
    outline = [(sx + 10, sy), (sx - 10, sy - 10),(sx - 10, sy + 10)]
    # Draw the ship
    pygame.draw.polygon(MY_WIN, pygame.color.Color('blue'), outline)

## ----------------------------------------------------------------------
##     Laser Functions
## ----------------------------------------------------------------------

def draw_lasers(lasers):
    '''Displays all the lasers as white circles.'''

    global MY_WIN
    #global RADIUS

    # Loop over the lasers.
    for laser in lasers:
        # Unpack the laser
        (bx, by) = laser
        # Draw the laser
        pygame.draw.circle(MY_WIN, pygame.color.Color('white'), (bx, by), RADIUS)


def move_lasers(lasers):
    '''Moves all the lasers to the right by LASER_DX, removes lasers that go out of the window.'''

    global LASER_DX
    global RADIUS
    global WIDTH

    # Make an empty list to store the updated lasers.
    new_lasers = []

    # Loop over the lasers moving them.
    for laser in lasers:
        # Unpack the laser.
        (bx, by) = laser
        # Move the laser to the right.
    #changed the laser trajectory to a cone instead of a straight line
        bx = bx + LASER_DX
        cone_range=random.randint(-15,15)
        by=by+cone_range
        cone_laser=(bx,by)

        
        # Appends to list of remaining lasers if still on screen
        if bx <= WIDTH + RADIUS:
            new_lasers.append(cone_laser)

    return new_lasers

## ----------------------------------------------------------------------
##     World Functions
## ----------------------------------------------------------------------

def draw_background():
    '''Displays the background by filling with black.'''

    global MY_WIN

   # MY_WIN.fill(pygame.color.Color("black"))

    background_img = pygame.image.load('space.bmp').convert()

    background_img = pygame.transform.scale(background_img, (WIDTH, HEIGHT))

    MY_WIN.blit(background_img, (0, 0))



def draw_score():
    '''Displays the score.'''

    global SCORE
    global MY_WIN
    global WIDTH

    font = pygame.font.SysFont("monospace", 20)
    score_display = font.render("Score: %d" % SCORE, 0, (255, 255, 255))
    MY_WIN.blit(score_display, (WIDTH - 150, 20))

## ----------------------------------------------------------------------
##     Alien Functions
## ----------------------------------------------------------------------

def move_alien(alien,x,y):
    '''
    Moves one alien. 
    Returns the (x,y) position the alien moves to. 
    Bug: Currently the alien chooses to stay where it is.
    '''
    (ax, ay) = alien
    ax=ax+x
    ay=ay+y
        
    ## Do nothing, but return the original position.
    return (ax, ay)
#modified 2. of playing with functions by making them move randomly in unison.
def move_aliens(aliens):
    '''Moves all aliens.'''
#random,randint to determine moving a short distance in a random direction
    x=random.randint(-10,10)
    y=random.randint(-10,10)
    for i in range(len(aliens)):
        aliens[i]=move_alien(aliens[i],x,y)
            
            
        


def draw_alien(alien):
    '''Draws one alien as a boring green circle.'''

#changed the color from green to red, changed the shape from a circle to a rectangle.
    global MY_WIN
    pygame.draw.rect(MY_WIN, pygame.color.Color('red'), (alien[0],alien[1],10,10))


def draw_aliens(aliens):
    '''Draws all the aliens in the list.'''

    for alien in aliens:
        draw_alien(alien)


def remove_aliens(aliens, lasers):
    '''Compares a list of aliens and lasers and removes lasers and
    aliens which collide.  Returns a tuple containing the updated
    lists of aliens and lasers.  
    Bug: Doesn't update the score.
    '''

    global RADIUS
    global SCORE

    new_aliens = []

    # Note: This code is complicated.  You could figure out how it
    # works, but that's not necessary for lab.
    for alien in aliens:
        collided = False
        for laser in lasers:
            if collide((alien, RADIUS), (laser, RADIUS)):
                print("Hit Alien!")
#Add 1 point to score everytime Alien is hit.
                SCORE+=1
                collided = True
                pygame.mixer.music.load("pop.wav")
                pygame.mixer.music.play(-1)
                break
        if collided:
            lasers.remove(laser)
        else:
            new_aliens.append(alien)
    return (new_aliens, lasers)


def add_aliens(aliens):
    '''Infrequently adds one alien to the list of aliens at a random position.
    Returns None.'''

    global HEIGHT
    global WIDTH
#changed 100 to 10 to increase chances by 10x
    if random.randint(0, 10) == 0:
        aliens.append((random.randint(100, WIDTH), random.randint(0, HEIGHT)))


## ----------------------------------------------------------------------
##     Main Game Loop
## ----------------------------------------------------------------------

def update_game(aliens, firing, lasers, ship, north, south, pause):
    if not pause:
        add_aliens(aliens)

        if firing:
            fire_laser(lasers, ship)
        if north==1:
            ship=move_ship_up(ship)
        if south==1:
            ship=move_ship_down(ship)

        lasers = move_lasers(lasers)
        move_aliens(aliens)

        # Remove aliens hit by lasers
        (aliens, lasers) = remove_aliens(aliens, lasers)

    return (aliens, lasers, ship)

def run_game():
     
    FPS = 100
    
    # Initialize objects in game: ship, lasers, aliens
    global ship 
    ship = (50, 240)
    lasers = []
    aliens = []

    frame = 0

    has_won = False

    firing = False
    moving = 0

    north = -1
    south = -1
    pause = False

    ## Load other resources
    #pygame.mixer.music.load("pop.wav")
    #pygame.mixer.music.play(-1)
    
    while (not has_won):

        frame += 1  
        ## Sleep so that the frames come at even intervals.
        time.sleep(1.0/FPS)

        ## ====================================================
        ##   Handle Events
        ## ====================================================

        events = pygame.event.get()
        #print events
        for event in events:
            #print "Type = ", event.type
            if event.type == pygame.QUIT:

                # Window close event -- Stop game!
                pygame.quit()
                return

            elif event.type == pygame.KEYDOWN:

                # Key pressed event
                key_pressed = event.dict['key']
                print("Key pressed = %s" % key_pressed)

                if key_pressed == pygame.K_UP:
                    north=1
                elif key_pressed==pygame.K_DOWN:
                    south=1
                elif key_pressed == ord(" "):
                    firing = True
                elif key_pressed == ord('q'):
                    pygame.quit()
                    return
                elif key_pressed == ord('p') and pause == False:
                    pause = True
                elif key_pressed == ord('p') and pause == True:
                    pause = False
                    
            
            elif event.type == pygame.KEYUP:

                # Key released event
                key_released = event.dict['key']
                print("Key released = %s" % key_released)

                if key_released == pygame.K_UP:
                    north=-1
                elif key_released==pygame.K_DOWN:
                    south=-1
                elif key_released == ord(" "):
                    firing = False
                elif key_released == ord('q'):
                    pygame.quit()
                    return

        ## ====================================================
        ##   Update Game
        ## ====================================================
        (aliens, lasers, ship) = update_game(aliens, firing, lasers, ship, north, south, pause)

        ## ====================================================
        ##   Display Game
        ## ====================================================

        ## Draw the objects in the game.
        draw_background()
        draw_lasers(lasers)
        draw_aliens(aliens)
        draw_ship(ship)
        draw_score()

        ## Show the pygame window.       
        pygame.display.update()
        
        ## The game loop ends here.

    ## This closes your pygame window after we have left the game
    ## loop, i.e., after somebody closed the window.
    pygame.quit()


## Call the function run_game.

run_game()
